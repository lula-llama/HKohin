ScoreObtained=35
total_points=35/50
percentage=ScoreObtained/total_points
print("percentage")
