Marks_Obtained=35
total_points=50
percentage=Marks_Obtained/total_points
print(percentage)
